<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <meta name="description"
          content="Genesis Mining is the largest and most trusted Bitcoin cloud mining provider in the world. We are dedicated to transparency, efficiency, and maximize your profits."/>
    <meta name="keywords"
          content="Bitcoin mining, scrypt mining, altcoin mining, cloud mining, X11, hosted mining"/>
    <meta name="format-detection" content="telephone=no"/>

    
    <title>euBRASIL | Genesis</title>
    <link rel="icon" type="image/x-icon"
          href="data:image/x-icon;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAHKklEQVRoge2af4hVxxXHP1mWRXyyLGG7bETstgQREQnSl1hr0qS/tOXGmmK1gZvERCRVm5q2tPbWlmDFToNtbeuvqNU0YWoaYxIJL8baP2rEWvGlEiSkslgrVkSsBJE+WeSx9I8zc9+8eXPvbKFUCH7/eXPPfmfumTsz55w5Z+EWbi5uy1tp1g2sAB4BhoDLwH7gWbS61tEzzcYB3wYWAxOBC8BLwK/RaiTA7wNWAwuAfuAs8DywA61GfXqjVp0IZMA8oBcYBrZVkvqezgmkWQ/wJvC5wCSHgXvR6rKjTC/wNnBXgH8c+CxaXXf4E4E/Ix/GRw14CK2ajvLTgD8BAwH+7kpSX2ofuszv9wqUB5gCbPNkGwqUB5gFKE+2s0B5gAR42pO9RFh5gCcateoi+2AnsLSAbLHAbAG7WmmEv4Q06zL8QeBLEX7+/kat+glgRoS/zDbsBIYiHbocziAwPsLvRfY5wMcjXIA7nfZY+DnHTuCDMXS64nA7Dp2HG8BV075cRgxwrhSyAhw7gdciHd5BqwsAaPVv4FCEfwCtbhj+GeC9CH+f0z5KfNKv2IadwBrEDIYwAjzpyVbR+sI+rgDf8mTLzDghnAXW2odKUr9h3le0yu8Am+2DTEBMZBX5Ek2HfAS4B61Otg2h1TBwD+0rMQocMPxzHv84cC9wzJE2gd8Dn0Srti1cSer7gbnAKUc8AjwHPFBJ6vnHuA0faTYBcUxX/IGDEOs0AFwKOrxOfj9ywC+Y7ViKRq06APQB513FPzQIrUA/MBlZgfOxAYzLHwQuVpL6pTHwh4DbgXOVpD6WFb4TMctnQivsxkJDwHbgC87fTwIrzR72FZmBeOjZjvgIsLyS1N8P8O8DtgDTHXHN8DsNSJrNBzbSsvlNYC/wlLu1bSw0CfgrYffdBD6NVvkBbNSq04G/ABMC/GtAtZLUhx3+/cAfge4A/4Lht1Yvzb6GhBMhvIcYiuvQMqPrC5THvNSPhX5VoDzIcv/ck20vUB5gEvBM/iRR7pYCLsgK5rGTncD8kg4AM0izyQCNWrUX+EyEP69Rq/YY/hQkICzDAqc9GzkjZfiybdgJ9EU6uJzeMXC7HV5/GTHA+a/4dgJnIh2awDnTvgTE7PdVWvFVbGyQO0eoHeXbCWyPdNhrTVglqTeB30b4OypJfdTwLxOPtVpnTKt3kXChDLm+dgK/QK6PIZwCnvJkq2kPC1wcxj2UguXA6QL+XmCrJ3uY4tjsl2iV6+r6gS7gUeAxWnfiV4HNbddDA3NIvw58FbEk54GXka/fDPDHI3foB2ndiV+oJHUdVDPNbge+S+tOfBrYjlZvFEzsFm4K2mKhRq3ah/iEIWQL1YJu3iLNBpBL+UeBfyAXmeLLiIQr8xCneRZ4ozSCTbOpSGhjt1DNT9nkE2jUqguBXbTb+SbwTCWp/yQw+DeQ7MQ4R3odWIVWvwnw1wE/oGU4QMzt4+6hNNxuYBNyxlxcBBaj1VEr6DLKz0EOoO+kuoH1jVq1faA0W2ReMM7jjwd2mkDM5T8N/NBTHsQ5vkKa3e3JNwSUB7mnvEWadVzq1wYGd7GuUau6f/fzPj7W5y1Jw/hm1UU3zpXSbMtvlvAnIGYcaCl9X0Shfmw8Iy+IpT6mm+wdSI4nFqrMcdqzKP+YbfwY0UWX9/u/5LucoqjVRc6xHWOu+xo2/tDqEuK0yjCMVjZrcQo53GVwL0wnItw2vnsGyqA877ouwm+NJ2bvZyXc0bbxJP+0u4R/A3jWPnQBVJL6QSRe6QgBgM2VpP7TNomYyR/TmbsZBdag1R5PvhZJifgYAZah1WFPvpJwAHgNyWTnV1bfkU0GFgIfA/4F7K8k9VMUIc2mGP4dwD+BfWh1toQ/E3F8HwH+jkS5F0v4c4AvIpbnb2b8saQeb+H/hva8UJoltJeYXgdedKsnDrcLWITE7oPYEpNW+zq4wu9BwvWHcMJptDpYwB+PeOO5iB95Hwmn21I87n1gF/BEYKijwFyvZNRjJhcqXLyGxCtNh98L/AFxUj62otVKT/mJSIkplAzI0Co3KraKsqJAeRCvt9GTrS1QHuArwPc92SbCygOsIM2WeLLfUZzJUKRZXg6zfsC/MvpYYpK+NlIMBVouWuPJzSpWklrl8KcB94+VbycwNdKhh1b8M0g8thkwMRPIl4yFE9Oc9vRCVgu5vnbgaJrb4YyFO4o4HZzfMricosJJSJd8AgciHYZzByUxTkey18Ph/OYkXjMWO7nvP0Z80jXbcEtMRZ1G6Twjq5CYJIQR4DuebGWIaPAB8KP8SYoeqwvZkmDLc6+2xHQGKQGd9MjngQfRqr2op9UJ4PN0ZtFOAw+Y5JTLl2p8Z67nBPCpjjqEVs8htWO/fnAI+a+BfJuFChxTaTmyd0P/x+Dx78I6Mq3Kq5Hi/GZiL/VaFSW7LL/H8PuA0x21tw8D/gMgZye0XekKOAAAAABJRU5ErkJggg=="/>
    <link rel="shortcut icon" type="image/x-icon"
          href="data:image/x-icon;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAHKklEQVRoge2af4hVxxXHP1mWRXyyLGG7bETstgQREQnSl1hr0qS/tOXGmmK1gZvERCRVm5q2tPbWlmDFToNtbeuvqNU0YWoaYxIJL8baP2rEWvGlEiSkslgrVkSsBJE+WeSx9I8zc9+8eXPvbKFUCH7/eXPPfmfumTsz55w5Z+EWbi5uy1tp1g2sAB4BhoDLwH7gWbS61tEzzcYB3wYWAxOBC8BLwK/RaiTA7wNWAwuAfuAs8DywA61GfXqjVp0IZMA8oBcYBrZVkvqezgmkWQ/wJvC5wCSHgXvR6rKjTC/wNnBXgH8c+CxaXXf4E4E/Ix/GRw14CK2ajvLTgD8BAwH+7kpSX2ofuszv9wqUB5gCbPNkGwqUB5gFKE+2s0B5gAR42pO9RFh5gCcateoi+2AnsLSAbLHAbAG7WmmEv4Q06zL8QeBLEX7+/kat+glgRoS/zDbsBIYiHbocziAwPsLvRfY5wMcjXIA7nfZY+DnHTuCDMXS64nA7Dp2HG8BV075cRgxwrhSyAhw7gdciHd5BqwsAaPVv4FCEfwCtbhj+GeC9CH+f0z5KfNKv2IadwBrEDIYwAjzpyVbR+sI+rgDf8mTLzDghnAXW2odKUr9h3le0yu8Am+2DTEBMZBX5Ek2HfAS4B61Otg2h1TBwD+0rMQocMPxzHv84cC9wzJE2gd8Dn0Srti1cSer7gbnAKUc8AjwHPFBJ6vnHuA0faTYBcUxX/IGDEOs0AFwKOrxOfj9ywC+Y7ViKRq06APQB513FPzQIrUA/MBlZgfOxAYzLHwQuVpL6pTHwh4DbgXOVpD6WFb4TMctnQivsxkJDwHbgC87fTwIrzR72FZmBeOjZjvgIsLyS1N8P8O8DtgDTHXHN8DsNSJrNBzbSsvlNYC/wlLu1bSw0CfgrYffdBD6NVvkBbNSq04G/ABMC/GtAtZLUhx3+/cAfge4A/4Lht1Yvzb6GhBMhvIcYiuvQMqPrC5THvNSPhX5VoDzIcv/ck20vUB5gEvBM/iRR7pYCLsgK5rGTncD8kg4AM0izyQCNWrUX+EyEP69Rq/YY/hQkICzDAqc9GzkjZfiybdgJ9EU6uJzeMXC7HV5/GTHA+a/4dgJnIh2awDnTvgTE7PdVWvFVbGyQO0eoHeXbCWyPdNhrTVglqTeB30b4OypJfdTwLxOPtVpnTKt3kXChDLm+dgK/QK6PIZwCnvJkq2kPC1wcxj2UguXA6QL+XmCrJ3uY4tjsl2iV6+r6gS7gUeAxWnfiV4HNbddDA3NIvw58FbEk54GXka/fDPDHI3foB2ndiV+oJHUdVDPNbge+S+tOfBrYjlZvFEzsFm4K2mKhRq3ah/iEIWQL1YJu3iLNBpBL+UeBfyAXmeLLiIQr8xCneRZ4ozSCTbOpSGhjt1DNT9nkE2jUqguBXbTb+SbwTCWp/yQw+DeQ7MQ4R3odWIVWvwnw1wE/oGU4QMzt4+6hNNxuYBNyxlxcBBaj1VEr6DLKz0EOoO+kuoH1jVq1faA0W2ReMM7jjwd2mkDM5T8N/NBTHsQ5vkKa3e3JNwSUB7mnvEWadVzq1wYGd7GuUau6f/fzPj7W5y1Jw/hm1UU3zpXSbMtvlvAnIGYcaCl9X0Shfmw8Iy+IpT6mm+wdSI4nFqrMcdqzKP+YbfwY0UWX9/u/5LucoqjVRc6xHWOu+xo2/tDqEuK0yjCMVjZrcQo53GVwL0wnItw2vnsGyqA877ouwm+NJ2bvZyXc0bbxJP+0u4R/A3jWPnQBVJL6QSRe6QgBgM2VpP7TNomYyR/TmbsZBdag1R5PvhZJifgYAZah1WFPvpJwAHgNyWTnV1bfkU0GFgIfA/4F7K8k9VMUIc2mGP4dwD+BfWh1toQ/E3F8HwH+jkS5F0v4c4AvIpbnb2b8saQeb+H/hva8UJoltJeYXgdedKsnDrcLWITE7oPYEpNW+zq4wu9BwvWHcMJptDpYwB+PeOO5iB95Hwmn21I87n1gF/BEYKijwFyvZNRjJhcqXLyGxCtNh98L/AFxUj62otVKT/mJSIkplAzI0Co3KraKsqJAeRCvt9GTrS1QHuArwPc92SbCygOsIM2WeLLfUZzJUKRZXg6zfsC/MvpYYpK+NlIMBVouWuPJzSpWklrl8KcB94+VbycwNdKhh1b8M0g8thkwMRPIl4yFE9Oc9vRCVgu5vnbgaJrb4YyFO4o4HZzfMricosJJSJd8AgciHYZzByUxTkey18Ph/OYkXjMWO7nvP0Z80jXbcEtMRZ1G6Twjq5CYJIQR4DuebGWIaPAB8KP8SYoeqwvZkmDLc6+2xHQGKQGd9MjngQfRqr2op9UJ4PN0ZtFOAw+Y5JTLl2p8Z67nBPCpjjqEVs8htWO/fnAI+a+BfJuFChxTaTmyd0P/x+Dx78I6Mq3Kq5Hi/GZiL/VaFSW7LL/H8PuA0x21tw8D/gMgZye0XekKOAAAAABJRU5ErkJggg=="/>

    
    
	<link rel="stylesheet" type="text/css" href="css/Version3/bootstrap.min.css" />
	<link rel="stylesheet" type="text/css" href="css/Version3/font-awesome.min.css" />
	<link rel="stylesheet" type="text/css" href="css/Version3/bootstrap-select.min.css" />
	<link rel="stylesheet" type="text/css" href="css/Version3/style_dash.css" />
	<link rel="stylesheet" type="text/css" href="css/Version3/custom.css" />

	<script type="text/javascript" src="js/Version3/jquery-2.1.2.min.js"></script>
	<script type="text/javascript" src="js/Version3/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/Version3/menu.js"></script>
	<script type="text/javascript" src="js/Version3/jquery.knob.js"></script>
	<script type="text/javascript" src="js/Version3/bootstrap-select.min.js"></script>
    <!--[if lte IE 9]>
    <script type="text/javascript" src="js/modernizr.js"></script>
    <script type="text/javascript" src="js/respond.min.js"></script>
    <script type="text/javascript" src="js/placeholders.min.js"></script>
    <![endif]-->

                <script>
            (function (i, s, o, g, r, a, m) {
                i['GoogleAnalyticsObject'] = r;
                i[r] = i[r] || function () {
                        (i[r].q = i[r].q || []).push(arguments)
                    }, i[r].l = 1 * new Date();
                a = s.createElement(o),
                    m = s.getElementsByTagName(o)[0];
                a.async = 1;
                a.src = g;
                m.parentNode.insertBefore(a, m)
            })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');

            ga('create', 'UA-30541749-13', 'auto');
            ga('require', 'displayfeatures');
            ga('send', 'pageview');
        </script>
    
            <style type="text/css">
        text[y="319.5"] {
            background-color: #121c29;
        }

        @media (max-width: 769px) {
            .trans-usr td.tdcreated:before {
                content: "Created";
            }

            .trans-usr td.tddcurrency:before {
                content: "Digital Currency";
            }

            .trans-usr td.tdcurrency:before {
                content: "Currency";
            }

            .trans-usr td.tdpayout:before {
                content: "Net payout";
            }

            .trans-usr td.tdsentto:before {
                content: "Sent to";
            }

            .trans-usr td.tdtranshash:before {
                content: "Transaction hash";
            }

            .trans-usr td.tdinfoao:before {
                content: "Info about order";
            }

            .trans-usr td.tdhashpower:before {
                content: "Hashpower";
            }

            .trans-usr td.tdinvoiceid:before {
                content: "Invoice ID";
            }

            .trans-usr td.tdocreated:before {
                content: "Order created";
            }

            .trans-usr td.tdstartdate:before {
                content: "Start date";
            }

            .trans-usr td.tdenddate:before {
                content: "End date";
            }

            .trans-usr td.tdprice:before {
                content: "Price";
            }

            .trans-usr td.tdpaid:before {
                content: "Paid";
            }

            .trans-usr td.tdostatus:before {
                content: "Order status";
            }

            .trans-usr td.tdtype:before {
                content: "Type";
            }

            .trans-usr td.tdminingday:before {
                content: "Mining Day";
            }

            .trans-usr td.tduser:before {
                content: "User";
            }

            .trans-usr td.tdnet:before {
                content: "Net";
            }

            .trans-usr td.tdbalance:before {
                content: "Balance";
            }

            .trans-usr td.tdactions:before {
                content: "Actions";
            }

            .trans-usr td.tdshorttitle:before {
                content: "Short title";
            }

            .trans-usr td.tddate:before {
                content: "Date";
            }

            .trans-usr td.tdpublished:before {
                content: "Publihed";
            }

            .trans-usr td.tdip:before {
                content: "IP Address";
            }

            .trans-usr td.tdid:before {
                content: "ID";
            }

            .trans-usr td.tdmail:before {
                content: "E-mail";
            }

            .trans-usr td.tdorders:before {
                content: "Orders";
            }

            .trans-usr td.tdorderid:before {
                content: "Order ID";
            }

            .trans-usr td.tdamount:before {
                content: "Amount";
            }

            .trans-usr td.tdconfirm:before {
                content: "Confirmations";
            }

            .trans-usr td.tdcode:before {
                content: "Code";
            }

            .trans-usr td.tdhash:before {
                content: "Hash";
            }

            .trans-usr td.tdstatus:before {
                content: "Status";
            }

            .trans-usr td.tdconversion:before {
                content: "Conversion rate";
            }

            .trans-usr td.tdservice:before {
                content: "Service";
            }

            .trans-usr td.tdquantity:before {
                content: "Quantity";
            }

            .trans-usr td.tdsubtotal:before {
                content: "Subtotal";
            }

            .trans-usr td.tdaffiliateid:before {
                content: "Affiliate ID";
            }

            .trans-usr td.tddescription:before {
                content: "Description";
            }

            .trans-usr td.tdhits:before {
                content: "Hits";
            }

            .trans-usr td.tdpending:before {
                content: "Pending";
            }

            .trans-usr td.tdapproved:before {
                content: "Approved";
            }

            .trans-usr td.tdearnings:before {
                content: "Earnings";
            }

            .trans-usr td.tdalgo:before {
                content: "Algorithm";
            }

            .trans-usr td.tdpercent:before {
                content: "Percentage";
            }

            .trans-usr td.tdsentto:before {
                content: "Sent to";
            }

            .trans-usr td.tdaddress:before {
                content: "Address";
            }

            .trans-usr td.tdinputs:before {
                content: "Input";
            }

            .trans-usr td.tdinputaddress:before {
                content: "Input Address";
            }

            .trans-usr td.tdcc:before {
                content: "CC";
            }

            .trans-usr td.tdintoday:before {
                content: "In Today";
            }

            .trans-usr td.tdinperiod:before {
                content: "In Period";
            }

            .trans-usr td.tdaccbalance:before {
                content: "Account balance";
            }

            .trans-usr td.tdusrpayballance:before {
                content: "Users Payment Balance";
            }

            .trans-usr td.tdbtcballance:before {
                content: "Balance BTC";
            }

            .trans-usr td.tdusdballance:before {
                content: "Balance USD";
            }

            .trans-usr td.tdxbtc:before {
                content: "X-rate BTC";
            }

            .trans-usr td.tdxusd:before {
                content: "X-rate USD";
            }

            .trans-usr td.tdrinputs:before {
                content: "Received Inputs";
            }

            .trans-usr td.tdrpayments:before {
                content: "Received payments";
            }

            .trans-usr td.tdaffcode:before {
                content: "Affiliate code";
            }

            .trans-usr td.tdusrpercentage:before {
                content: "User percentage";
            }

            .trans-usr td.tdaffpercentage:before {
                content: "Affiliate percentage";
            }

            .trans-usr td.tdcurrencyname:before {
                content: "Crypto Currency Name";
            }

            .trans-usr td.tdcurrencycode:before {
                content: "Currency Code";
            }

            .trans-usr td.tdbtype:before {
                content: "Banner Type";
            }

            .trans-usr td.tdbsize:before {
                content: "Banner Size (px)";
            }

            .trans-usr td.tdbformat:before {
                content: "Banner Format";
            }

            .trans-usr td.tdbpreview:before {
                content: "Banner Preview";
            }

            .trans-usr td.tdbdownload:before {
                content: "Banner Download";
            }

            .trans-usr td.tdposttitle:before {
                content: "Post title";
            }

            .trans-usr td.tdpostcategory:before {
                content: "Post category";
            }

            .trans-usr td.tdpublishdate:before {
                content: "Publish date";
            }
        }
    </style>
            <script type="text/javascript">
            adroll_adv_id = "ZYGXJBUN7ZGOPACQVXFFBY";
            adroll_pix_id = "YANWPSUX7BC5JPSD5MEZPJ";
            (function () {
                var oldonload = window.onload;
                window.onload = function () {
                    __adroll_loaded = true;
                    var scr = document.createElement("script");
                    var host = (("https:" == document.location.protocol) ? "https://s.adroll.com"
                        : "http://a.adroll.com");
                    scr.setAttribute('async', 'true');
                    scr.type = "text/javascript";
                    scr.src = host + "/j/roundtrip.js";
                    ((document.getElementsByTagName('head') || [null])[0] ||
                    document.getElementsByTagName('script')[0].parentNode).appendChild(scr);
                    if (oldonload) {
                        oldonload()
                    }
                };
            }());
        </script>
        <script type="text/javascript">var _kmq = _kmq || [];
            var _kmk = _kmk || '2700f421a76d827cbf11f5f8099b08e11837c20b';
            function _kms(u) {
                setTimeout(function () {
                    var d = document, f = d.getElementsByTagName('script')[0], s = d.createElement('script');
                    s.type = 'text/javascript';
                    s.async = true;
                    s.src = u;
                    f.parentNode.insertBefore(s, f);
                }, 1);
            }
            _kms('//i.kissmetrics.com/i.js');
            _kms('//doug1izaerwt3.cloudfront.net/' + _kmk + '.1.js'); </script>
    </head>
<body>
<header>
    <nav class="navbar navbar-fixed-top" role="navigation">
<div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#main-menu">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
    </button>
            <a class="navbar-brand" href="/dashboard">GM</a>
    </div>
<div class="navbar-header-container">
    <div class="container">
        <div class="mma">
            <div class="row">
                <div class="col-lg-9 col-md-8 col-sm-8 col-xs-8">
                                            <h1>euBRASIL( Minerar 0.2TH )</h1>
                                                                <p>Www. euBRASIL . ( ml | Mercado Livre )</p>
                                    </div>
                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-4">
				<span class="limiter">
					<h2>Brazil , SP</h2>
                                            <p><a href="/logout"><span class="fa fa-power-off"></span> Logout</a></p>
                    				</span>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="collapse navbar-collapse" id="main-menu">
<ul class="nav navbar-nav">

                        <li class="start-mining">
                <a class="navbar-link" href="http://bit.ly/Minerar-004TH" target="blank">
                    <b>Comprar | Minerar</b></a>
            </li>
                <li>
            <a class="navbar-link" href="/dashboard"><span class="fa fa-home"></span> <b
                    class="nav-text">Dashboard</b></a>
        </li>
        <li class="active">
            <a class="navbar-link" href="/mining-allocation"><span class="fa fa-signal"></span> <b
                    class="nav-text">Mining Allocation</b></a>
        </li>
        <li>
            <a class="navbar-link" href="/payouts"><span class="fa fa-list-ul"></span> <b
                    class="nav-text">Payouts</b></a>
        </li>
        <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="fa fa-user"></span> <b
                    class="nav-text">My Account</b> <b class="caret"></b></a>
            <ul class="dropdown-menu">
                <li>
                    <a href="/my-account"><span class="fa fa-cogs"></span> <b class="nav-text">Settings</b></a>
                </li>
                <li>
                    <a href="/affiliate-program"><span class="fa fa-star"></span> <b class="nav-text">Affiliate</b></a>
                </li>
                <li>
                    <a class="navbar-link" href="/my-orders"><span class="fa fa-shopping-cart"></span> <b
                            class="nav-text">My orders</b></a>
                </li>
                <li>
                    <a href="/contact-support"><span
                            class="fa fa-comments"></span> <b class="nav-text">Contact support</b></a>
                </li>
            </ul>
        </li>
        <li>
            <a class="navbar-link" href="/upgrade-hashpower/universal"><span class="fa fa-bolt"></span>
                <b class="nav-text">
                    Upgrade Hashpower                </b>
            </a>
        </li>
                                                    </ul>
</div>
</nav></header>
<div style="display: none;">
    2016-09-16 22:50:43</div>
<div id="main-container">
    <div class="container">
        <div id="mma-flash" class="mma">
            <div class="row">
                <div class="col-sm-12"></div>
            </div>
        </div>
            <div id="mma-flash" class="mma">
        <div class="row">
            <div class="col-sm-12">
                <div class="alert alert-info fade in" style="margin-bottom:35px;">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times-circle"></i></button>
					<h4>Notice!</h4>
                    <p>Please order hashpower <a href="/upgrade-hashpower">here</a> to start mining!</p>
                </div>
            </div>
        </div>
    </div>
            <div id="mma-flash" class="mma">
            <div class="row">
                <div class="col-sm-12">
                    <div class="alert alert-info fade in" style="margin-bottom:35px;">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times-circle"></i></button>
                        <h4>Important note!</h4>

                        <p>Please set your BTC address <a href="/my-account">here</a> to be able to receive BTC. </p>
                    </div>
                </div>
            </div>
        </div>
    
<div id="algo-selection" class="mma mma-bc1">
    <div id="word-selected" style="display:none;"><i class="fa fa-check-square-o"></i>Selected</div>
    <div id="word-select" style="display:none;"><i class="fa fa-check"></i>Select</div>
    <div class="row">
                                <div class="col-sm-4 has-box" data-algo="sha256" data-selected="0">
                <div class="has  has-sha256 selected">
                    <div class="hmc">
                        <h3><span>BTC | 7,00</span></h3>

                        <p>BITcoin | BRL Real</p>
                                                    <a class="btn btn-warning button-sha256"><i
                                    class="fa fa-check-square-o"></i>Selected</a>
                                            </div>
                </div>
            </div>
                                            <div class="col-sm-4 has-box" data-algo="x11" data-selected="0">
                <div class="has  has-x11">
                    <div class="hmc">
                        <h3><span>LITE | 3,50</span></h3>

                        <p>LITEcoin | BRL Real</p>
                                                    <a class="btn btn-warning button-x11"><i
                                    class="fa fa-check"></i>Select</a>
                                            </div>
                </div>
            </div>
                                            <div class="col-sm-4 has-box" data-algo="dagger-hashimoto" data-selected="0">
                <div class="has  has-dagger-hashimoto">
                    <div class="hmc">
                        <h3><span>DOGE | 0,50</span></h3>

                        <p>DOGEcoin | BRL Real</p>
                                                    <a class="btn btn-warning button-dagger-hashimoto"><i
                                    class="fa fa-check"></i>Select</a>
                                            </div>
                </div>
            </div>
                        </div>
</div>


<div class="allocation-settings mma mma-bc1">
<div class="row">
	<div class="col-xs-12">
	<div class="row">
		<div class="col-xs-6">
		<div class="save-ma">
			<h3>Save mining allocation</h3>
			<p>Allocate your hashpower</p>
            <a style="" href="#" class="btn btn-warning save-allocation" role="button"><i style="" class="fa fa-download"></i>Save allocation</a>
		</div>
		</div>

		<div class="col-xs-6">
		<div class="reset-ma">
			<h3>Reset mining allocation</h3>
			<p>Purchase more hashpower</p>
			<a style="" href="#" class="btn btn-primary reset-allocation reset-allocation-sha256" role="button"><i class="fa fa-refresh"></i>Reset allocation</a>
		</div>
		</div>
	</div>
	</div>
</div>
</div>


<script type="text/javascript">
    $(document).ready(function () {
        var algos = {};
                                    algos["sha256"] = "sha256";
                                                algos["x11"] = "x11";
                                                algos["dagger-hashimoto"] = "dagger-hashimoto";
                    
        function changeDistributionType(_algos) {
            Object.keys(_algos).forEach(function (k) {
                var checkDistributionExistance = $(document).find('[data-distribution-type="' + k + '"]');
                if (checkDistributionExistance.length > 0) {
                    checkDistributionExistance.hide().attr('data-selected', 0);
                }
            });
            var select = $('#word-select').html();
            var selected = $('#word-selected').html();
            $('.has-box').click(function () {
                var _el = $(this);
                $('#save-form-info').attr('data-form-algo', _el.attr('data-algo'));

                _el.attr('data-selected', 1);
                Object.keys(_algos).forEach(function (k) {
                    $('.reset-allocation').each(function(){
                        $(this).removeClass('reset-allocation-' + k).addClass('reset-allocation-' + _el.attr('data-algo'));
                    });
                    if (k === _el.attr('data-algo')) {
                        _el.find('a.button-' + _el.attr('data-algo')).html(selected);
                        $('.has-' + k).removeClass('selected').addClass('selected');
                        var checkDistributionExistance = $(document).find('[data-distribution-type="' + k + '"]');
                        if (checkDistributionExistance.length > 0)
                            checkDistributionExistance.show();
                        $('#show-total-hp-' + k).show();
                    } else {
                            var checkDistributionWindow = $(document).find('[data-algo="' + k + '"]');
                            if (checkDistributionWindow.length > 0) {
                                checkDistributionWindow.attr('data-selected', 0);
                                checkDistributionWindow.find('a.button-' + checkDistributionWindow.attr('data-algo')).html(select);
                            }
                            var checkDistributionExistance = $(document).find('[data-distribution-type="' + k + '"]');
                            if (checkDistributionExistance.length > 0)
                                checkDistributionExistance.hide();
                            $('.has-' + k).removeClass('selected');
                            $('#show-total-hp-' + k).hide();
                    }
                });
            })
        }

        changeDistributionType(algos);
        $(document).find('[data-distribution-type="sha256"]').show().attr('data-selected', 1);
        $('.show-total').each(function(){
            var _this_algo = $(this).attr('data-algo');
            var _selected_algo = 'sha256';
            if(_this_algo == _selected_algo)
                $(this).show();
            else
                $(this).hide();
        });
    });
</script>


    <div id="allocate-hashpower" class="mma mma-sha256" data-distribution-type="sha256">
<form action="/mining-allocation" class="form-horizontal" name="UserMiningDistributionForm_sha256" id="UserMiningDistributionForm_sha256" method="post" accept-charset="utf-8"><div style="display:none;"><input type="hidden" name="_method" value="POST"/><input type="hidden" name="data[_Token][key]" value="81f3895dcce1c03a9335483dd7589f6657413537" id="Token1806483421"/></div><input type="hidden" name="data[User][id]" class="form-control" value="57ae010b35a6a29f3d8b47ba" id="UserId"/><div class="row currencies-mining-distribution">
    <div style="display:none;">
        <div id="algo-coins-sha256" data-value='["BTC","UNO","BTCD","DRK","LTC","DOGE","ZET"]'></div>
        <div id="mining-allocation-sha256"
             data-value='{"BTC":100,"UNO":0,"BTCD":0,"DRK":0,"LTC":0,"DOGE":0,"ZET":0}'></div>
    </div>

<div class="col-xs-6 col-sm-6 col-md-4 col-lg-3 coin-allocate text-center"><div class="mab"><h3 class="coin-allocate-title">BTC<span><a href="http://bravenewcoin.com/coins/bitcoin" target="_blank">BTC</a></span></h3><input name="data[User][Mining_sha256][BTC]" class="knob-sha256 BTC-sha256" data-inputcolor="#0e3a56" data-fgcolor="#00607b" data-step="5" data-algo="sha256" data-bgcolor="#f3f3f3" data-currency-name="BTC" data-width="125" data-thickness=".25" data-skin="tron" data-font="&quot;Signika&quot;,&quot;Arial&quot;,sans-serif" default="0" value="100" type="text" id="UserMiningSha256BTC"/><h4 class="currency-value" id="BTC_value_sha256">0.00 TH/s</h4><a href="#" class="btn btn-more btn-more-BTC"><i class="fa fa-info-circle"></i>More info</a><div class="coin-info-box cib-BTC">
	
		<ul>
			<li><b>Name:</b> Bitcoin</li>
			<li><b>Currency Code:</b> BTC</li>
			<li><b>Algorithm:</b> sha256</li>
			<li><b>Max Coins:</b> 21,000,000</li>
			<li><b>Block Time:</b> 10 minutes</li>
			<li><b>Consensus:</b> Proof of Work</li>
			<li><b>Homepage:</b> <a href="https://bitcoin.org/en" target="_blank" title="Bitcoin">bitcoin.org</a></li>
			<li><b>Description:</b> The first decentralized digital currency. Invented by Satoshi Nakamoto. The most wide spread crypto currency.</li>
		</ul>	
		<a href="#" class="btn btn-warning btn-close btn-close-BTC"><i class="fa fa-times-circle"></i>Close</a>
			
	</div></div></div>    <span id="BTC_perc_sha256" data-value="100"
          style="display:none;"></span>
    <span id="total_mh_sha256" data-value="0" style="display:none;"></span>

<div class="col-xs-6 col-sm-6 col-md-4 col-lg-3 coin-allocate text-center"><div class="mab"><h3 class="coin-allocate-title">UNO<span><a href="http://bravenewcoin.com/coins/unobtanium" target="_blank">UNO</a></span></h3><input name="data[User][Mining_sha256][UNO]" class="knob-sha256 UNO-sha256" data-inputcolor="#0e3a56" data-fgcolor="#00607b" data-step="5" data-algo="sha256" data-bgcolor="#f3f3f3" data-currency-name="UNO" data-width="125" data-thickness=".25" data-skin="tron" data-font="&quot;Signika&quot;,&quot;Arial&quot;,sans-serif" default="0" value="0" type="text" id="UserMiningSha256UNO"/><h4 class="currency-value" id="UNO_value_sha256">0.00 TH/s</h4><a href="#" class="btn btn-more btn-more-UNO"><i class="fa fa-info-circle"></i>More info</a><div class="coin-info-box cib-UNO">
	
		<ul>
			<li><b>Name:</b> Unobtanium</li>
			<li><b>Currency Code:</b> UNO</li>
			<li><b>Algorithm:</b> sha256</li>
			<li><b>Max Coins:</b> 250,000</li>
			<li><b>Block Time:</b> 3 minutes</li>
			<li><b>Consensus:</b> Proof of Work</li>
			<li><b>Homepage:</b> <a href="http://unobtanium.uno/" target="_blank" title="Unobtanium">unobtanium.uno</a></li>
			<li><b>Description:</b> Unobtanium derived it's name from conceptual Unobtanium, describing an extremely rare, impossible or costly material.</li>
		</ul>	
		<a href="#" class="btn btn-warning btn-close btn-close-UNO"><i class="fa fa-times-circle"></i>Close</a>
			
	</div></div></div>    <span id="UNO_perc_sha256" data-value="0"
          style="display:none;"></span>
    <span id="total_mh_sha256" data-value="0" style="display:none;"></span>

<div class="col-xs-6 col-sm-6 col-md-4 col-lg-3 coin-allocate text-center"><div class="mab"><h3 class="coin-allocate-title">BTCD&nbsp;(AUTO)<span><a href="http://bravenewcoin.com/coins/bitcoindark" target="_blank">BTCD</a></span></h3><input name="data[User][Mining_sha256][BTCD]" class="knob-sha256 BTCD-sha256" data-inputcolor="#0e3a56" data-fgcolor="#00607b" data-step="5" data-algo="sha256" data-bgcolor="#f3f3f3" data-currency-name="BTCD" data-width="125" data-thickness=".25" data-skin="tron" data-font="&quot;Signika&quot;,&quot;Arial&quot;,sans-serif" default="0" value="0" type="text" id="UserMiningSha256BTCD"/><h4 class="currency-value" id="BTCD_value_sha256">0.00 TH/s</h4><a href="#" class="btn btn-more btn-more-BTCD"><i class="fa fa-info-circle"></i>More info</a><div class="coin-info-box cib-BTCD">
	
		<ul>
			<li><b>Name:</b> BitcoinDark</li>
			<li><b>Currency Code:</b> BTCD</li>
			<li><b>Algorithm:</b> sha256</li>
			<li><b>Max Coins:</b> 1,200,000</li>
			<li><b>Block Time:</b> 1 minute</li>
			<li><b>Consensus:</b> Proof of Work</li>
			<li><b>Homepage:</b> <a href="http://bitcoindark.pw/" target="_blank" title="BitcoinDark">bitcoindark.pw</a></li>
			<li><b>Description:</b> BitcoinDark will be the first cryptocurrency to pay regular dividends in form other than itself.</li>
		</ul>	
		<a href="#" class="btn btn-warning btn-close btn-close-BTCD"><i class="fa fa-times-circle"></i>Close</a>
			
	</div></div></div>    <span id="BTCD_perc_sha256" data-value="0"
          style="display:none;"></span>
    <span id="total_mh_sha256" data-value="0" style="display:none;"></span>

<div class="col-xs-6 col-sm-6 col-md-4 col-lg-3 coin-allocate text-center"><div class="mab"><h3 class="coin-allocate-title">DASH&nbsp;(AUTO)<span><a href="http://bravenewcoin.com/coins/darkcoin" target="_blank">DASH</a></span></h3><input name="data[User][Mining_sha256][DRK]" class="knob-sha256 DRK-sha256" data-inputcolor="#0e3a56" data-fgcolor="#00607b" data-step="5" data-algo="sha256" data-bgcolor="#f3f3f3" data-currency-name="DRK" data-width="125" data-thickness=".25" data-skin="tron" data-font="&quot;Signika&quot;,&quot;Arial&quot;,sans-serif" default="0" value="0" type="text" id="UserMiningSha256DRK"/><h4 class="currency-value" id="DRK_value_sha256">0.00 TH/s</h4><a href="#" class="btn btn-more btn-more-DRK"><i class="fa fa-info-circle"></i>More info</a><div class="coin-info-box cib-DRK">
	
		<ul>
			<li><b>Name:</b> Dash</li>
			<li><b>Currency Code:</b> DASH</li>
			<li><b>Algorithm:</b> x11</li>
			<li><b>Max Coins:</b> 22,000,000</li>
			<li><b>Block Time:</b> 2.5 minutes</li>
			<li><b>Consensus:</b> Proof of Work</li>
			<li><b>Homepage:</b> <a href="https://www.dashpay.io/" target="_blank" title="Dash">dashpay.io</a></li>
			<li><b>Description:</b> DASH goal is the true anonymity of transactions and wallet owners on its network. Supports Darksend.</li>
		</ul>	
		<a href="#" class="btn btn-warning btn-close btn-close-DRK"><i class="fa fa-times-circle"></i>Close</a>
			
	</div></div></div>    <span id="DRK_perc_sha256" data-value="0"
          style="display:none;"></span>
    <span id="total_mh_sha256" data-value="0" style="display:none;"></span>

<div class="col-xs-6 col-sm-6 col-md-4 col-lg-3 coin-allocate text-center"><div class="mab"><h3 class="coin-allocate-title">LTC&nbsp;(AUTO)<span><a href="http://bravenewcoin.com/coins/litecoin" target="_blank">LTC</a></span></h3><input name="data[User][Mining_sha256][LTC]" class="knob-sha256 LTC-sha256" data-inputcolor="#0e3a56" data-fgcolor="#00607b" data-step="5" data-algo="sha256" data-bgcolor="#f3f3f3" data-currency-name="LTC" data-width="125" data-thickness=".25" data-skin="tron" data-font="&quot;Signika&quot;,&quot;Arial&quot;,sans-serif" default="0" value="0" type="text" id="UserMiningSha256LTC"/><h4 class="currency-value" id="LTC_value_sha256">0.00 TH/s</h4><a href="#" class="btn btn-more btn-more-LTC"><i class="fa fa-info-circle"></i>More info</a><div class="coin-info-box cib-LTC">
	
		<ul>
			<li><b>Name:</b> Litecoin</li>
			<li><b>Currency Code:</b> LTC</li>
			<li><b>Algorithm:</b> scrypt</li>
			<li><b>Max Coins:</b> 84,000,000</li>
			<li><b>Block Time:</b> 2.50 minutes</li>
			<li><b>Consensus:</b> Proof of Work </li>
			<li><b>Homepage:</b> <a href="https://litecoin.org/" target="_blank" title="Litecoin">litecoin.org</a></li>
			<li><b>Description:</b> Litecoin is a peer-to-peer Internet currency that enables instant payments to anyone in the world. It is based on the Bitcoin protocol but differs from Bitcoin in that it can be efficiently mined with consumer-grade hardware.</li>
		</ul>	
		<a href="#" class="btn btn-warning btn-close btn-close-LTC"><i class="fa fa-times-circle"></i>Close</a>
			
	</div></div></div>    <span id="LTC_perc_sha256" data-value="0"
          style="display:none;"></span>
    <span id="total_mh_sha256" data-value="0" style="display:none;"></span>

<div class="col-xs-6 col-sm-6 col-md-4 col-lg-3 coin-allocate text-center"><div class="mab"><h3 class="coin-allocate-title">DOGE&nbsp;(AUTO)<span><a href="http://bravenewcoin.com/coins/dogecoin" target="_blank">DOGE</a></span></h3><input name="data[User][Mining_sha256][DOGE]" class="knob-sha256 DOGE-sha256" data-inputcolor="#0e3a56" data-fgcolor="#00607b" data-step="5" data-algo="sha256" data-bgcolor="#f3f3f3" data-currency-name="DOGE" data-width="125" data-thickness=".25" data-skin="tron" data-font="&quot;Signika&quot;,&quot;Arial&quot;,sans-serif" default="0" value="0" type="text" id="UserMiningSha256DOGE"/><h4 class="currency-value" id="DOGE_value_sha256">0.00 TH/s</h4><a href="#" class="btn btn-more btn-more-DOGE"><i class="fa fa-info-circle"></i>More info</a><div class="coin-info-box cib-DOGE">
	
		<ul>
			<li><b>Name:</b> Dogecoin</li>
			<li><b>Currency Code:</b> DOGE</li>
			<li><b>Algorithm:</b> scrypt</li>
			<li><b>Max Coins:</b> 100,000,000,000</li>
			<li><b>Block Time:</b> 1 minute</li>
			<li><b>Consensus:</b> Proof of Work</li>
			<li><b>Homepage:</b> <a href="http://dogecoin.com/" target="_blank" title="Dogecoin">dogecoin.com</a></li>
			<li><b>Description:</b> Was created in December 2013, and promoted as a fun coin. In particular used for tipping other users.</li>
		</ul>	
		<a href="#" class="btn btn-warning btn-close btn-close-DOGE"><i class="fa fa-times-circle"></i>Close</a>
			
	</div></div></div>    <span id="DOGE_perc_sha256" data-value="0"
          style="display:none;"></span>
    <span id="total_mh_sha256" data-value="0" style="display:none;"></span>

<div class="col-xs-6 col-sm-6 col-md-4 col-lg-3 coin-allocate text-center"><div class="mab"><h3 class="coin-allocate-title">ZET<span><a href="http://bravenewcoin.com/coins/zetacoin" target="_blank">ZET</a></span></h3><input name="data[User][Mining_sha256][ZET]" class="knob-sha256 ZET-sha256" data-inputcolor="#0e3a56" data-fgcolor="#00607b" data-step="5" data-algo="sha256" data-bgcolor="#f3f3f3" data-currency-name="ZET" data-width="125" data-thickness=".25" data-skin="tron" data-font="&quot;Signika&quot;,&quot;Arial&quot;,sans-serif" default="0" value="0" type="text" id="UserMiningSha256ZET"/><h4 class="currency-value" id="ZET_value_sha256">0.00 TH/s</h4><a href="#" class="btn btn-more btn-more-ZET"><i class="fa fa-info-circle"></i>More info</a><div class="coin-info-box cib-ZET">
	
		<ul>
			<li><b>Name:</b> Zetacoin</li>
			<li><b>Currency Code:</b> ZET</li>
			<li><b>Algorithm:</b> sha256</li>
			<li><b>Max Coins:</b> 160,000,000</li>
			<li><b>Block Time:</b> 30 seconds</li>
			<li><b>Consensus:</b> Proof of Work</li>
			<li><b>Homepage:</b> <a href="http://zetacoin.com/" target="_blank" title="Zetacoin">zetacoin.com</a></li>
			<li><b>Description:</b> Zetacoin is an open source crypto-currency based on Bitcoin. It has faster transaction times and faster difficulty adjustments. Initial coin mining is 160 million coins, thereafter a yearly inflation of 1 million coins.</li>
		</ul>	
		<a href="#" class="btn btn-warning btn-close btn-close-ZET"><i class="fa fa-times-circle"></i>Close</a>
			
	</div></div></div>    <span id="ZET_perc_sha256" data-value="0"
          style="display:none;"></span>
    <span id="total_mh_sha256" data-value="0" style="display:none;"></span>
    <script type="text/javascript">
        $(document).ready(function () {
		

            //custom method for number format
            Number.prototype.formatNumber = function (c, d, t) {
                var n = this,
                    c = isNaN(c = Math.abs(c)) ? 2 : c,
                    d = d == undefined ? "." : d,
                    t = t == undefined ? "," : t,
                    s = n < 0 ? "-" : "",
                    i = parseInt(n = Math.abs(+n || 0).toFixed(c)) + "",
                    j = (j = i.length) > 3 ? j % 3 : 0;
                return s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
            };

            var _current_algo = 'sha256';

            var allocated = {"***":100,"***":0,"***":0,"***":0,"***":0,"***":0,"***":0,};
            var checkAllocated = Object.getOwnPropertyNames(allocated).length === 0;

            var totalMH = [];
            totalMH = parseFloat($('#total_mh_' + _current_algo).attr('data-value'));
            totalMH = totalMH.formatNumber(2, '.', '');

            var current_coins = JSON.parse($('#algo-coins-' + _current_algo).attr('data-value'));


            if (!checkAllocated) {

                //default setup for knobs
                $('.knob-' + _current_algo).knob({
                    'release': function () {
                        this.$.trigger('allocation', [this.cv, this.$]);
                    }
                });

                //callbacks for knobs
                $('input.knob-' + _current_algo).on('allocation', function (event, wantedVal, currentCoin) {
                    var _currentCoinsValues = {};
                    var _currCurrency = $(this).data('currency-name');
                    current_coins.forEach(function (coin) {
                        _currentCoinsValues[coin] = 0;
                    });
                    var _sumOther = 0;
                    $('.knob-' + _current_algo).each(function () {
                        var _val = parseFloat($(this).val());
                        var _currency = $(this).data('currency-name');
                        _currentCoinsValues[_currency] = _val;
                        if (_currency != _currCurrency)
                            _sumOther += _val;
                    });

                    var _autoCurrency = 'BTC';
                    if (_currCurrency == 'BTC')
                        _autoCurrency = 'BTCD';

                    var _autoVal = _currentCoinsValues[_autoCurrency];
                    var _oldCurrVal = 100 - _sumOther;
                    var _oldCurrValAbs = Math.abs(wantedVal - _oldCurrVal);

                    var _checkUno = parseFloat(_autoVal) + parseFloat(wantedVal);
                    var _checkDuo = 100 - _checkUno;
                    var _checkDuoAbs = Math.abs(100 - _checkUno);

                    if (wantedVal > _oldCurrVal) {
                        var checkAutoVal = _autoVal - _oldCurrValAbs;
                        if (checkAutoVal < 0) {
                            wantedVal = _oldCurrVal + _autoVal;
                            _autoVal = 0;
                        } else
                            _autoVal = checkAutoVal;
                    }
                    // decreasing the current slider, increase the auto
                    if (wantedVal < _oldCurrVal)
                        _autoVal += _oldCurrValAbs;


                    _currentCoinsValues[_currCurrency] = wantedVal;
                    _currentCoinsValues[_autoCurrency] = _autoVal;


                    $('.knob-' + _current_algo).each(function () {
                        //shutdown callback temporary
                        $(this).trigger('configure', {
                            'release': function () {
                                return;
                            }
                        });

                        if(_current_algo == 'x11')
                            var _unnit = 'MH/s';

                        if(_current_algo == 'dagger-hashimoto')
                            var _unnit = 'MH/s';

                        if(_current_algo == 'sha256')
                            var _unnit = 'TH/s';

                        var _coin = $(this).data('currency-name');
                        var _val = _currentCoinsValues[_coin];
                        var finalPerc = parseFloat(totalMH * _val / 100).formatNumber(2, '.', '');
                        $('#' + _coin + '_value_' + _current_algo).text(finalPerc + ' ' + _unnit);
                        if (_coin != _currCurrency)
                            $(this).val(_val).trigger('change');

                        //bring callback up again
                        $(this).trigger('configure', {
                            'release': function () {
                                this.$.trigger('allocation', [this.cv, this.$]);
                            }
                        });
                    });
                });

                $('.reset-allocation').click(function (e) {
                    var _current_algo = $('#save-form-info').attr('data-form-algo');
                    e.preventDefault();
                    $('.knob-' + _current_algo).each(function () {
                        $(this).trigger('configure', {
                            'release': function () {
                                return;
                            }
                        });
                        var curr_currency = $(this).attr('data-currency-name');
                        var set_val = 0;
                        if (curr_currency == 'BTC')
                            set_val = 100;

                        if(_current_algo == 'x11')
                            var _unnit = 'MH/s';

                        if(_current_algo == 'dagger-hashimoto')
                            var _unnit = 'MH/s';

                        if(_current_algo == 'sha256')
                            var _unnit = 'TH/s';

                        var finalPerc = parseFloat(totalMH * set_val / 100).formatNumber(2, '.', '');
                        $('#' + $(this).data('currency-name') + '_value_' + _current_algo).text(finalPerc + ' ' + _unnit);

                        $(this).val(set_val).trigger('change');
                        $(this).trigger('configure', {
                            'release': function () {
                                this.$.trigger('allocation', [this.cv, this.$]);
                            }
                        });
                    });
                });

                $('.save-' + _current_algo).click(function (e) {
                    e.preventDefault();
                    $('#UserMiningDistributionForm_' + _current_algo).submit();
                });
            }

            $(".btn-close").click(function(e){
                e.preventDefault();
                $(this).parent().hide("fast");
            });
            $(".btn-more").click(function(e){
                e.preventDefault();
                $(this).next().show("fast");
            });

        })
    </script>
</div>
<div style="display:none;"><input type="hidden" name="data[_Token][fields]" value="5f2c24b161c7626a772e874018485c59822a6140%3AUser.id" id="TokenFields517728336"/><input type="hidden" name="data[_Token][unlocked]" value="" id="TokenUnlocked816440574"/></div></form>

</div><!-- #allocate-hashpower euBRASIL(2) -->
<?php include 'litecoin.php' ; ?>
</div><!-- #allocate-hashpower euBRASIL(2) -->


    <div id="allocate-hashpower" class="mma mma-dagger-hashimoto" data-distribution-type="dagger-hashimoto">
<form action="/mining-allocation" class="form-horizontal" name="UserMiningDistributionForm_dagger-hashimoto" id="UserMiningDistributionForm_dagger-hashimoto" method="post" accept-charset="utf-8"><div style="display:none;"><input type="hidden" name="_method" value="POST"/><input type="hidden" name="data[_Token][key]" value="81f3895dcce1c03a9335483dd7589f6657413537" id="Token832426044"/></div><input type="hidden" name="data[User][id]" class="form-control" value="57ae010b35a6a29f3d8b47ba" id="UserId"/><div class="row currencies-mining-distribution">
    <div style="display:none;">
        <div id="algo-coins-dagger-hashimoto" data-value='["BTC","ETH"]'></div>
        <div id="mining-allocation-dagger-hashimoto"
             data-value='{"BTC":50,"ETH":50}'></div>
    </div>

<div class="col-xs-6 col-sm-6 col-md-4 col-lg-3 coin-allocate text-center"><div class="mab"><h3 class="coin-allocate-title">BTC&nbsp;(AUTO)<span><a href="http://bravenewcoin.com/coins/bitcoin" target="_blank">BTC</a></span></h3><input name="data[User][Mining_daggerHashimoto][BTC]" class="knob-dagger-hashimoto BTC-dagger-hashimoto" data-inputcolor="#0e3a56" data-fgcolor="#00607b" data-step="5" data-algo="dagger-hashimoto" data-bgcolor="#f3f3f3" data-currency-name="BTC" data-width="125" data-thickness=".25" data-skin="tron" data-font="&quot;Signika&quot;,&quot;Arial&quot;,sans-serif" default="0" value="100" type="text" id="UserMiningDaggerHashimotoBTC"/><h4 class="currency-value" id="BTC_value_dagger-hashimoto">0.00 MH/s</h4><a href="#" class="btn btn-more btn-more-BTC"><i class="fa fa-info-circle"></i>More info</a><div class="coin-info-box cib-BTC">
	
		<ul>
			<li><b>Name:</b> Bitcoin</li>
			<li><b>Currency Code:</b> BTC</li>
			<li><b>Algorithm:</b> sha256</li>
			<li><b>Max Coins:</b> 21,000,000</li>
			<li><b>Block Time:</b> 10 minutes</li>
			<li><b>Consensus:</b> Proof of Work</li>
			<li><b>Homepage:</b> <a href="https://bitcoin.org/en" target="_blank" title="Bitcoin">bitcoin.org</a></li>
			<li><b>Description:</b> The first decentralized digital currency. Invented by Satoshi Nakamoto. The most wide spread crypto currency.</li>
		</ul>	
		<a href="#" class="btn btn-warning btn-close btn-close-BTC"><i class="fa fa-times-circle"></i>Close</a>
			
	</div></div></div>    <span id="BTC_perc_dagger-hashimoto" data-value="100"
          style="display:none;"></span>
    <span id="total_mh_dagger-hashimoto" data-value="0" style="display:none;"></span>

<div class="col-xs-6 col-sm-6 col-md-4 col-lg-3 coin-allocate text-center"><div class="mab"><h3 class="coin-allocate-title">ETH<span><a href="http://bravenewcoin.com/coins/ether" target="_blank">ETH</a></span></h3><input name="data[User][Mining_daggerHashimoto][ETH]" class="knob-dagger-hashimoto ETH-dagger-hashimoto" data-inputcolor="#0e3a56" data-fgcolor="#00607b" data-step="5" data-algo="dagger-hashimoto" data-bgcolor="#f3f3f3" data-currency-name="ETH" data-width="125" data-thickness=".25" data-skin="tron" data-font="&quot;Signika&quot;,&quot;Arial&quot;,sans-serif" default="0" value="0" type="text" id="UserMiningDaggerHashimotoETH"/><h4 class="currency-value" id="ETH_value_dagger-hashimoto">0.00 MH/s</h4><a href="#" class="btn btn-more btn-more-ETH"><i class="fa fa-info-circle"></i>More info</a><div class="coin-info-box cib-ETH">
	
		<ul>
			<li><b>Name:</b> Ethereum</li>
			<li><b>Currency Code:</b> ETH</li>
			<li><b>Algorithm:</b> Ethash</li>
			<li><b>Max Coins:</b> 60,000,000 + 15,000,000/year</li>
			<li><b>Block Time:</b> 12 Seconds</li>
			<li><b>Consensus:</b> Proof of Work</li>
			<li><b>Homepage:</b> <a href="https://ethereum.org" target="_blank" title="Ethereum">ethereum.org</a></li>
			<li><b>Description:</b> A distributed platform that allows users to write and enforce their own (smart) contracts. Some call it 'Bitcoin 2.0'.</li>
		</ul>	
		<a href="#" class="btn btn-warning btn-close btn-close-ETH"><i class="fa fa-times-circle"></i>Close</a>
			
	</div></div></div>    <span id="ETH_perc_dagger-hashimoto" data-value="0"
          style="display:none;"></span>
    <span id="total_mh_dagger-hashimoto" data-value="0" style="display:none;"></span>
    <script type="text/javascript">
        $(document).ready(function () {
		

            //custom method for number format
            Number.prototype.formatNumber = function (c, d, t) {
                var n = this,
                    c = isNaN(c = Math.abs(c)) ? 2 : c,
                    d = d == undefined ? "." : d,
                    t = t == undefined ? "," : t,
                    s = n < 0 ? "-" : "",
                    i = parseInt(n = Math.abs(+n || 0).toFixed(c)) + "",
                    j = (j = i.length) > 3 ? j % 3 : 0;
                return s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
            };

            var _current_algo = 'dagger-hashimoto';

            var allocated = {"BTC":100,"ETH":0,};
            var checkAllocated = Object.getOwnPropertyNames(allocated).length === 0;

            var totalMH = [];
            totalMH = parseFloat($('#total_mh_' + _current_algo).attr('data-value'));
            totalMH = totalMH.formatNumber(2, '.', '');

            var current_coins = JSON.parse($('#algo-coins-' + _current_algo).attr('data-value'));


            if (!checkAllocated) {

                //default setup for knobs
                $('.knob-' + _current_algo).knob({
                    'release': function () {
                        this.$.trigger('allocation', [this.cv, this.$]);
                    }
                });

                //callbacks for knobs
                $('input.knob-' + _current_algo).on('allocation', function (event, wantedVal, currentCoin) {
                    var _currentCoinsValues = {};
                    var _currCurrency = $(this).data('currency-name');
                    current_coins.forEach(function (coin) {
                        _currentCoinsValues[coin] = 0;
                    });
                    var _sumOther = 0;
                    $('.knob-' + _current_algo).each(function () {
                        var _val = parseFloat($(this).val());
                        var _currency = $(this).data('currency-name');
                        _currentCoinsValues[_currency] = _val;
                        if (_currency != _currCurrency)
                            _sumOther += _val;
                    });

                    var _autoCurrency = 'BTC';
                    if (_currCurrency == 'BTC')
                        _autoCurrency = 'BTCD';

                    var _autoVal = _currentCoinsValues[_autoCurrency];
                    var _oldCurrVal = 100 - _sumOther;
                    var _oldCurrValAbs = Math.abs(wantedVal - _oldCurrVal);

                    var _checkUno = parseFloat(_autoVal) + parseFloat(wantedVal);
                    var _checkDuo = 100 - _checkUno;
                    var _checkDuoAbs = Math.abs(100 - _checkUno);

                    if (wantedVal > _oldCurrVal) {
                        var checkAutoVal = _autoVal - _oldCurrValAbs;
                        if (checkAutoVal < 0) {
                            wantedVal = _oldCurrVal + _autoVal;
                            _autoVal = 0;
                        } else
                            _autoVal = checkAutoVal;
                    }
                    // decreasing the current slider, increase the auto
                    if (wantedVal < _oldCurrVal)
                        _autoVal += _oldCurrValAbs;


                    _currentCoinsValues[_currCurrency] = wantedVal;
                    _currentCoinsValues[_autoCurrency] = _autoVal;


                    $('.knob-' + _current_algo).each(function () {
                        //shutdown callback temporary
                        $(this).trigger('configure', {
                            'release': function () {
                                return;
                            }
                        });

                        if(_current_algo == 'x11')
                            var _unnit = 'MH/s';

                        if(_current_algo == 'dagger-hashimoto')
                            var _unnit = 'MH/s';

                        if(_current_algo == 'sha256')
                            var _unnit = 'TH/s';

                        var _coin = $(this).data('currency-name');
                        var _val = _currentCoinsValues[_coin];
                        var finalPerc = parseFloat(totalMH * _val / 100).formatNumber(2, '.', '');
                        $('#' + _coin + '_value_' + _current_algo).text(finalPerc + ' ' + _unnit);
                        if (_coin != _currCurrency)
                            $(this).val(_val).trigger('change');

                        //bring callback up again
                        $(this).trigger('configure', {
                            'release': function () {
                                this.$.trigger('allocation', [this.cv, this.$]);
                            }
                        });
                    });
                });

                $('.reset-allocation').click(function (e) {
                    var _current_algo = $('#save-form-info').attr('data-form-algo');
                    e.preventDefault();
                    $('.knob-' + _current_algo).each(function () {
                        $(this).trigger('configure', {
                            'release': function () {
                                return;
                            }
                        });
                        var curr_currency = $(this).attr('data-currency-name');
                        var set_val = 0;
                        if (curr_currency == 'BTC')
                            set_val = 100;

                        if(_current_algo == 'x11')
                            var _unnit = 'MH/s';

                        if(_current_algo == 'dagger-hashimoto')
                            var _unnit = 'MH/s';

                        if(_current_algo == 'sha256')
                            var _unnit = 'TH/s';

                        var finalPerc = parseFloat(totalMH * set_val / 100).formatNumber(2, '.', '');
                        $('#' + $(this).data('currency-name') + '_value_' + _current_algo).text(finalPerc + ' ' + _unnit);

                        $(this).val(set_val).trigger('change');
                        $(this).trigger('configure', {
                            'release': function () {
                                this.$.trigger('allocation', [this.cv, this.$]);
                            }
                        });
                    });
                });

                $('.save-' + _current_algo).click(function (e) {
                    e.preventDefault();
                    $('#UserMiningDistributionForm_' + _current_algo).submit();
                });
            }

            $(".btn-close").click(function(e){
                e.preventDefault();
                $(this).parent().hide("fast");
            });
            $(".btn-more").click(function(e){
                e.preventDefault();
                $(this).next().show("fast");
            });

        })
    </script>
</div>
<div style="display:none;"><input type="hidden" name="data[_Token][fields]" value="0a171e3a060cdd39d17e57444e864edc831c9453%3AUser.id" id="TokenFields437319894"/><input type="hidden" name="data[_Token][unlocked]" value="" id="TokenUnlocked1139093730"/></div></form>

</div><!-- #allocate-hashpower -->


<div class="allocation-settings mma mma-bc1">
    <div class="row">
        <div class="col-xs-12">
            <div class="row">
                <div class="col-xs-6">
                    <div class="save-ma">
                        <h3>Save mining allocation</h3>
                        <p>Allocate your hashpower</p>
                        <a href="#" class="btn btn-warning save-allocation" role="button"><i style="" class="fa fa-download"></i>Save allocation</a>
                    </div>
                </div>

                <div class="col-xs-6">
                    <div class="reset-ma">
                        <h3>Reset mining allocation</h3>
                        <p>Purchase more hashpower</p>
                        <a href="#" class="btn btn-primary reset-allocation reset-allocation-sha256" role="button"><i class="fa fa-refresh"></i>Reset allocation</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div style="display: none;" id="save-form-info" data-form-algo="sha256"></div>
<script type="text/javascript">
    $(document).ready(function(){
        $('.save-allocation').click(function(e){
            e.preventDefault();
            var selectedTabAlgo = $('#save-form-info').attr('data-form-algo');
            $('#UserMiningDistributionForm_' + selectedTabAlgo).submit();
        });
    });
</script>
    </div>
</div>

<div id="footer-container">
    <footer class="container">
        <div class="mma">
            <p class="">
                &copy; 2016 genesis-mining.com is property of Genesis Mining company. All rights reserved.            </p>
        </div>
    </footer>
</div>
<div id="mpo"></div>
<div id="the-loader">
    <div class="loader-content">
        <p>Your request is being proccessed. Please wait</p>
        <img src="/img/ajax-loader.gif" alt="Loader"/>
    </div>
</div>

<script>
    $(document).ready(function () {
        $('.hp ul a').click(function () {
            var sel = $(this).attr('data-option');
            if (sel == '-') {
                $('.hp-val').val('');
                $('.hp-holder').show();

            } else {
                $('.hp-val').val(sel);
                $('.hp-holder').hide();
            }
        })

        $('h5').popover();


    })
</script>
</body>
</html>
