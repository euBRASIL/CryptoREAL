    <div id="allocate-hashpower" class="mma mma-x11" data-distribution-type="x11">
<form action="/mining-allocation" class="form-horizontal" name="UserMiningDistributionForm_x11" id="UserMiningDistributionForm_x11" method="post" accept-charset="utf-8"><div style="display:none;"><input type="hidden" name="_method" value="POST"/><input type="hidden" name="data[_Token][key]" value="81f3895dcce1c03a9335483dd7589f6657413537" id="Token1237541006"/></div><input type="hidden" name="data[User][id]" class="form-control" value="57ae010b35a6a29f3d8b47ba" id="UserId"/><div class="row currencies-mining-distribution">
    <div style="display:none;">
        <div id="algo-coins-x11" data-value='["DRK","BTC","START","LTC","DOGE","BTCD","PPC","NMC","CURE","XMR"]'></div>
        <div id="mining-allocation-x11"
             data-value='{"BTC":100,"START":0,"DRK":0,"LTC":0,"DOGE":0,"BTCD":0,"PPC":0,"NMC":0,"CURE":0,"XMR":0}'></div>
    </div>

<div class="col-xs-6 col-sm-6 col-md-4 col-lg-3 coin-allocate text-center">
<div class="mab"><h3 class="coin-allocate-title">DASH<span><a href="http://bravenewcoin.com/coins/darkcoin" target="_blank">DASH</a></span></h3>
<input name="data[User][Mining_x11][DRK]" class="knob-x11 DRK-x11" data-inputcolor="#0e3a56" data-fgcolor="#00607b" data-step="5" data-algo="x11" data-bgcolor="#f3f3f3" data-currency-name="DRK" data-width="125" data-thickness=".25" data-skin="tron" data-font="&quot;Signika&quot;,&quot;Arial&quot;,sans-serif" default="0" value="0" type="text" id="UserMiningX11DRK"/><h4 class="currency-value" id="DRK_value_x11">0.00 MH/s</h4><a href="#" class="btn btn-more btn-more-DRK">
<i class="fa fa-info-circle"></i>Saiba (+)</a><div class="coin-info-box cib-DRK">
	
		<ul>
			<li><b>Name:</b> Dash</li>
			<li><b>Currency Code:</b> DASH</li>
			<li><b>Algorithm:</b> x11</li>
			<li><b>Max Coins:</b> 22,000,000</li>
			<li><b>Block Time:</b> 2.5 minutes</li>
			<li><b>Consensus:</b> Proof of Work</li>
			<li><b>Homepage:</b> <a href="https://www.dashpay.io/" target="_blank" title="Dash">dashpay.io</a></li>
			<li><b>Description:</b> DASH aims to be the first privacy-centric cryptographic currency with fully encrypted transactions and anonymous block transactions. These features are a work on progress and will be released in stages in the near future.</li>
		</ul>	
		<a href="#" class="btn btn-warning btn-close btn-close-DRK"><i class="fa fa-times-circle"></i>Close</a>
			
	</div></div></div>    <span id="DRK_perc_x11" data-value="0"
          style="display:none;"></span>
    <span id="total_mh_x11" data-value="0" style="display:none;"></span>

<div class="col-xs-6 col-sm-6 col-md-4 col-lg-3 coin-allocate text-center"><div class="mab">
<h3 class="coin-allocate-title">BTC&nbsp;(AUTO)<span>
<a href="http://bravenewcoin.com/coins/bitcoin" target="_blank">BTC</a></span></h3>
<input name="data[User][Mining_x11][BTC]" class="knob-x11 BTC-x11" data-inputcolor="#0e3a56" data-fgcolor="#00607b" data-step="5" data-algo="x11" data-bgcolor="#f3f3f3" data-currency-name="BTC" data-width="125" data-thickness=".25" data-skin="tron" data-font="&quot;Signika&quot;,&quot;Arial&quot;,sans-serif" default="0" value="100" type="text" id="UserMiningX11BTC"/><h4 class="currency-value" id="BTC_value_x11">0.00 MH/s</h4><a href="#" class="btn btn-more btn-more-BTC">
<i class="fa fa-info-circle"></i>Saiba (+)</a><div class="coin-info-box cib-BTC">
	
		<ul>
			<li><b>Name:</b> Bitcoin</li>
			<li><b>Currency Code:</b> BTC</li>
			<li><b>Algorithm:</b> sha256</li>
			<li><b>Max Coins:</b> 21,000,000</li>
			<li><b>Block Time:</b> 10 minutes</li>
			<li><b>Consensus:</b> Proof of Work</li>
			<li><b>Homepage:</b> <a href="https://bitcoin.org/en" target="_blank" title="Bitcoin">bitcoin.org</a></li>
			<li><b>Description:</b> The first decentralized digital currency. Invented by Satoshi Nakamoto. The most wide spread crypto currency.</li>
		</ul>	
		<a href="#" class="btn btn-warning btn-close btn-close-BTC"><i class="fa fa-times-circle"></i>Close</a>
			
	</div></div></div>    <span id="BTC_perc_x11" data-value="100"
          style="display:none;"></span>
    <span id="total_mh_x11" data-value="0" style="display:none;"></span>

<div class="col-xs-6 col-sm-6 col-md-4 col-lg-3 coin-allocate text-center">
<div class="mab"><h3 class="coin-allocate-title">START<span><a href="http://bravenewcoin.com/coins/startcoin" target="_blank">START</a></span></h3>
<input name="data[User][Mining_x11][START]" class="knob-x11 START-x11" data-inputcolor="#0e3a56" data-fgcolor="#00607b" data-step="5" data-algo="x11" data-bgcolor="#f3f3f3" data-currency-name="START" data-width="125" data-thickness=".25" data-skin="tron" data-font="&quot;Signika&quot;,&quot;Arial&quot;,sans-serif" default="0" value="0" type="text" id="UserMiningX11START"/><h4 class="currency-value" id="START_value_x11">0.00 MH/s</h4><a href="#" class="btn btn-more btn-more-START">
<i class="fa fa-info-circle"></i>Saiba (+)</a><div class="coin-info-box cib-START">
	
		<ul>
			<li><b>Name:</b> Startcoin</li>
			<li><b>Currency Code:</b> START</li>
			<li><b>Algorithm:</b> x11</li>
			<li><b>Max Coins:</b> 84,000,000</li>
			<li><b>Block Time:</b> 60 seconds</li>
			<li><b>Consensus:</b> Proof of Work</li>
			<li><b>Homepage:</b> <a href="https://startcoin.org/#whatis" target="_blank" title="Startcoin">startcoin.org</a></li>
			<li><b>Description:</b> StartCOIN is a digital currency that rewards you for supporting change. The more you share and support projects or the more StartCOIN you hold, the more StartCOINs you will receive. By joining the startjoin community, you become part of this crowd funding revolution.</li>
		</ul>	
		<a href="#" class="btn btn-warning btn-close btn-close-START"><i class="fa fa-times-circle"></i>Close</a>
			
	</div></div></div>    <span id="START_perc_x11" data-value="0"
          style="display:none;"></span>
    <span id="total_mh_x11" data-value="0" style="display:none;"></span>

<div class="col-xs-6 col-sm-6 col-md-4 col-lg-3 coin-allocate text-center">
<div class="mab"><h3 class="coin-allocate-title">LTC&nbsp;(AUTO)<span><a href="http://bravenewcoin.com/coins/litecoin" target="_blank">LTC</a></span></h3>
<input name="data[User][Mining_x11][LTC]" class="knob-x11 LTC-x11" data-inputcolor="#0e3a56" data-fgcolor="#00607b" data-step="5" data-algo="x11" data-bgcolor="#f3f3f3" data-currency-name="LTC" data-width="125" data-thickness=".25" data-skin="tron" data-font="&quot;Signika&quot;,&quot;Arial&quot;,sans-serif" default="0" value="0" type="text" id="UserMiningX11LTC"/><h4 class="currency-value" id="LTC_value_x11">0.00 MH/s</h4><a href="#" class="btn btn-more btn-more-LTC">
<i class="fa fa-info-circle"></i>Saiba (+)</a><div class="coin-info-box cib-LTC">
	
		<ul>
			<li><b>Name:</b> Litecoin</li>
			<li><b>Currency Code:</b> LTC</li>
			<li><b>Algorithm:</b> scrypt</li>
			<li><b>Max Coins:</b> 84,000,000</li>
			<li><b>Block Time:</b> 2.50 minutes</li>
			<li><b>Consensus:</b> Proof of Work </li>
			<li><b>Homepage:</b> <a href="https://litecoin.org/" target="_blank" title="Litecoin">litecoin.org</a></li>
			<li><b>Description:</b> Litecoin is a peer-to-peer Internet currency that enables instant payments to anyone in the world. It is based on the Bitcoin protocol but differs from Bitcoin in that it can be efficiently mined with consumer-grade hardware.</li>
		</ul>	
		<a href="#" class="btn btn-warning btn-close btn-close-LTC"><i class="fa fa-times-circle"></i>Close</a>
			
	</div></div></div>    <span id="LTC_perc_x11" data-value="0"
          style="display:none;"></span>
    <span id="total_mh_x11" data-value="0" style="display:none;"></span>

<div class="col-xs-6 col-sm-6 col-md-4 col-lg-3 coin-allocate text-center">
<div class="mab"><h3 class="coin-allocate-title">DOGE&nbsp;(AUTO)<span><a href="http://bravenewcoin.com/coins/dogecoin" target="_blank">DOGE</a></span></h3>
<input name="data[User][Mining_x11][DOGE]" class="knob-x11 DOGE-x11" data-inputcolor="#0e3a56" data-fgcolor="#00607b" data-step="5" data-algo="x11" data-bgcolor="#f3f3f3" data-currency-name="DOGE" data-width="125" data-thickness=".25" data-skin="tron" data-font="&quot;Signika&quot;,&quot;Arial&quot;,sans-serif" default="0" value="0" type="text" id="UserMiningX11DOGE"/><h4 class="currency-value" id="DOGE_value_x11">0.00 MH/s</h4><a href="#" class="btn btn-more btn-more-DOGE">
<i class="fa fa-info-circle"></i>Saiba (+)</a><div class="coin-info-box cib-DOGE">
	
		<ul>
			<li><b>Name:</b> Dogecoin</li>
			<li><b>Currency Code:</b> DOGE</li>
			<li><b>Algorithm:</b> scrypt</li>
			<li><b>Max Coins:</b> 100,000,000,000</li>
			<li><b>Block Time:</b> 1 minute</li>
			<li><b>Consensus:</b> Proof of Work</li>
			<li><b>Homepage:</b> <a href="http://dogecoin.com/" target="_blank" title="Dogecoin">dogecoin.com</a></li>
			<li><b>Description:</b> Was created in December 2013, and promoted as a fun coin. In particular used for tipping other users.</li>
		</ul>	
		<a href="#" class="btn btn-warning btn-close btn-close-DOGE"><i class="fa fa-times-circle"></i>Close</a>
			
	</div></div></div>    <span id="DOGE_perc_x11" data-value="0"
          style="display:none;"></span>
    <span id="total_mh_x11" data-value="0" style="display:none;"></span>

<div class="col-xs-6 col-sm-6 col-md-4 col-lg-3 coin-allocate text-center">
<div class="mab"><h3 class="coin-allocate-title">BTCD&nbsp;(AUTO)<span><a href="http://bravenewcoin.com/coins/bitcoindark" target="_blank">BTCD</a></span></h3>
<input name="data[User][Mining_x11][BTCD]" class="knob-x11 BTCD-x11" data-inputcolor="#0e3a56" data-fgcolor="#00607b" data-step="5" data-algo="x11" data-bgcolor="#f3f3f3" data-currency-name="BTCD" data-width="125" data-thickness=".25" data-skin="tron" data-font="&quot;Signika&quot;,&quot;Arial&quot;,sans-serif" default="0" value="0" type="text" id="UserMiningX11BTCD"/><h4 class="currency-value" id="BTCD_value_x11">0.00 MH/s</h4><a href="#" class="btn btn-more btn-more-BTCD">
<i class="fa fa-info-circle"></i>Saiba (+)</a><div class="coin-info-box cib-BTCD">
	
		<ul>
			<li><b>Name:</b> BitcoinDark</li>
			<li><b>Currency Code:</b> BTCD</li>
			<li><b>Algorithm:</b> sha256</li>
			<li><b>Max Coins:</b> 1,200,000</li>
			<li><b>Block Time:</b> 1 minute</li>
			<li><b>Consensus:</b> Proof of Work</li>
			<li><b>Homepage:</b> <a href="http://bitcoindark.pw/" target="_blank" title="BitcoinDark">bitcoindark.pw</a></li>
			<li><b>Description:</b> BitcoinDark will be the first cryptocurrency to pay regular dividends in form other than itself.</li>
		</ul>	
		<a href="#" class="btn btn-warning btn-close btn-close-BTCD"><i class="fa fa-times-circle"></i>Close</a>
			
	</div></div></div>    <span id="BTCD_perc_x11" data-value="0"
          style="display:none;"></span>
    <span id="total_mh_x11" data-value="0" style="display:none;"></span>

<div class="col-xs-6 col-sm-6 col-md-4 col-lg-3 coin-allocate text-center">
<div class="mab"><h3 class="coin-allocate-title">PPC&nbsp;(AUTO)<span><a href="http://bravenewcoin.com/coins/peercoin" target="_blank">PPC</a></span></h3>
<input name="data[User][Mining_x11][PPC]" class="knob-x11 PPC-x11" data-inputcolor="#0e3a56" data-fgcolor="#00607b" data-step="5" data-algo="x11" data-bgcolor="#f3f3f3" data-currency-name="PPC" data-width="125" data-thickness=".25" data-skin="tron" data-font="&quot;Signika&quot;,&quot;Arial&quot;,sans-serif" default="0" value="0" type="text" id="UserMiningX11PPC"/><h4 class="currency-value" id="PPC_value_x11">0.00 MH/s</h4><a href="#" class="btn btn-more btn-more-PPC">
<i class="fa fa-info-circle"></i>Saiba (+)</a><div class="coin-info-box cib-PPC">
	
		<ul>
			<li><b>Name:</b> PeerCoin</li>
			<li><b>Currency Code:</b> PPC</li>
			<li><b>Algorithm:</b> sha256</li>
			<li><b>Max Coins:</b> no maximum</li>
			<li><b>Block Time:</b> 10 minutes</li>
			<li><b>Consensus:</b> Proof of stake</li>
			<li><b>Homepage:</b> <a href="http://peercoin.net/" target="_blank" title="PeerCoin">peercoin.net</a></li>
			<li><b>Description:</b> Peercoin is an experimental, decentralized digital currency that enables instant payments to anyone, anywhere in the world. Peercoin uses peer-to-peer technology to operate with no central authority: managing transactions and issuing money are carried out collectively by the network.</li>
		</ul>	
		<a href="#" class="btn btn-warning btn-close btn-close-PPC"><i class="fa fa-times-circle"></i>Close</a>
			
	</div></div></div>    <span id="PPC_perc_x11" data-value="0"
          style="display:none;"></span>
    <span id="total_mh_x11" data-value="0" style="display:none;"></span>

<div class="col-xs-6 col-sm-6 col-md-4 col-lg-3 coin-allocate text-center">
<div class="mab"><h3 class="coin-allocate-title">NMC&nbsp;(AUTO)<span><a href="http://bravenewcoin.com/coins/namecoin" target="_blank">NMC</a></span></h3>
<input name="data[User][Mining_x11][NMC]" class="knob-x11 NMC-x11" data-inputcolor="#0e3a56" data-fgcolor="#00607b" data-step="5" data-algo="x11" data-bgcolor="#f3f3f3" data-currency-name="NMC" data-width="125" data-thickness=".25" data-skin="tron" data-font="&quot;Signika&quot;,&quot;Arial&quot;,sans-serif" default="0" value="0" type="text" id="UserMiningX11NMC"/><h4 class="currency-value" id="NMC_value_x11">0.00 MH/s</h4><a href="#" class="btn btn-more btn-more-NMC">
<i class="fa fa-info-circle"></i>Saiba (+)</a><div class="coin-info-box cib-NMC">
	
		<ul>
			<li><b>Name:</b> NameCoin</li>
			<li><b>Currency Code:</b> NMC</li>
			<li><b>Algorithm:</b> sha256</li>
			<li><b>Max Coins:</b> 21,000,000</li>
			<li><b>Block Time:</b> 14 days</li>
			<li><b>Consensus:</b> Proof of work</li>
			<li><b>Homepage:</b> <a href="https://namecoin.info/" target="_blank" title="NameCoin">namecoin.info</a></li>
			<li><b>Description:</b> Namecoin is a decentralized open source information registration and transfer system based on the Bitcoin cryptocurrency.</li>
		</ul>	
		<a href="#" class="btn btn-warning btn-close btn-close-NMC"><i class="fa fa-times-circle"></i>Close</a>
			
	</div></div></div>    <span id="NMC_perc_x11" data-value="0"
          style="display:none;"></span>
    <span id="total_mh_x11" data-value="0" style="display:none;"></span>

<div class="col-xs-6 col-sm-6 col-md-4 col-lg-3 coin-allocate text-center">
<div class="mab"><h3 class="coin-allocate-title">CURE&nbsp;(AUTO)<span><a href="http://bravenewcoin.com/coins/curecoin" target="_blank">CURE</a></span></h3>
<input name="data[User][Mining_x11][CURE]" class="knob-x11 CURE-x11" data-inputcolor="#0e3a56" data-fgcolor="#00607b" data-step="5" data-algo="x11" data-bgcolor="#f3f3f3" data-currency-name="CURE" data-width="125" data-thickness=".25" data-skin="tron" data-font="&quot;Signika&quot;,&quot;Arial&quot;,sans-serif" default="0" value="0" type="text" id="UserMiningX11CURE"/><h4 class="currency-value" id="CURE_value_x11">0.00 MH/s</h4><a href="#" class="btn btn-more btn-more-CURE">
<i class="fa fa-info-circle"></i>Saiba (+)</a><div class="coin-info-box cib-CURE">
	
		<ul>
			<li><b>Name:</b> CureCoin</li>
			<li><b>Currency Code:</b> CURE</li>
			<li><b>Algorithm:</b> sha256</li>
			<li><b>Max Coins:</b> 1,200,000</li>
			<li><b>Block Time:</b> </li>
			<li><b>Consensus:</b> Folding + SHA256 (PoW) + Proof of Stake</li>
			<li><b>Homepage:</b> <a href="https://www.curecoin.net/" target="_blank" title="CureCoin">curecoin.net</a></li>
			<li><b>Description:</b> CureCoin is a CryptoCurrency based on coupling SHA-256 Mining and Folding@Home Protein Folding.</li>
		</ul>	
		<a href="#" class="btn btn-warning btn-close btn-close-CURE"><i class="fa fa-times-circle"></i>Close</a>
			
	</div></div></div>    <span id="CURE_perc_x11" data-value="0"
          style="display:none;"></span>
    <span id="total_mh_x11" data-value="0" style="display:none;"></span>

<div class="col-xs-6 col-sm-6 col-md-4 col-lg-3 coin-allocate text-center">
<div class="mab"><h3 class="coin-allocate-title">XMR&nbsp;(AUTO)<span><a href="http://bravenewcoin.com/coins/monero" target="_blank">XMR</a></span></h3>
<input name="data[User][Mining_x11][XMR]" class="knob-x11 XMR-x11" data-inputcolor="#0e3a56" data-fgcolor="#00607b" data-step="5" data-algo="x11" data-bgcolor="#f3f3f3" data-currency-name="XMR" data-width="125" data-thickness=".25" data-skin="tron" data-font="&quot;Signika&quot;,&quot;Arial&quot;,sans-serif" default="0" value="0" type="text" id="UserMiningX11XMR"/><h4 class="currency-value" id="XMR_value_x11">0.00 MH/s</h4><a href="#" class="btn btn-more btn-more-XMR">
<i class="fa fa-info-circle"></i>Saiba (+)</a><div class="coin-info-box cib-XMR">
	
		<ul>
			<li><b>Name:</b> Monero</li>
			<li><b>Currency Code:</b> XMR</li>
			<li><b>Algorithm:</b> cryptonight</li>
			<li><b>Max Coins:</b> Infinite</li>
			<li><b>Block Time:</b> 120 seconds</li>
			<li><b>Consensus:</b> Proof of work</li>
			<li><b>Homepage:</b> <a href="https://getmonero.org/home" target="_blank" title="Monero">getmonero.org</a></li>
			<li><b>Description:</b> Monero aims to be a fungible and untraceable digital medium of exchange.</li>
		</ul>	
		<a href="#" class="btn btn-warning btn-close btn-close-XMR"><i class="fa fa-times-circle"></i>Close</a>
			
	</div></div></div>    <span id="XMR_perc_x11" data-value="0"
          style="display:none;"></span>
    <span id="total_mh_x11" data-value="0" style="display:none;"></span>
    <script type="text/javascript">
        $(document).ready(function () {
		

            //custom method for number format
            Number.prototype.formatNumber = function (c, d, t) {
                var n = this,
                    c = isNaN(c = Math.abs(c)) ? 2 : c,
                    d = d == undefined ? "." : d,
                    t = t == undefined ? "," : t,
                    s = n < 0 ? "-" : "",
                    i = parseInt(n = Math.abs(+n || 0).toFixed(c)) + "",
                    j = (j = i.length) > 3 ? j % 3 : 0;
                return s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
            };

            var _current_algo = 'x11';

            var allocated = {"BTC":100,"START":0,"DRK":0,"LTC":0,"DOGE":0,"BTCD":0,"PPC":0,"NMC":0,"CURE":0,"XMR":0,};
            var checkAllocated = Object.getOwnPropertyNames(allocated).length === 0;

            var totalMH = [];
            totalMH = parseFloat($('#total_mh_' + _current_algo).attr('data-value'));
            totalMH = totalMH.formatNumber(2, '.', '');

            var current_coins = JSON.parse($('#algo-coins-' + _current_algo).attr('data-value'));


            if (!checkAllocated) {

                //default setup for knobs
                $('.knob-' + _current_algo).knob({
                    'release': function () {
                        this.$.trigger('allocation', [this.cv, this.$]);
                    }
                });

                //callbacks for knobs
                $('input.knob-' + _current_algo).on('allocation', function (event, wantedVal, currentCoin) {
                    var _currentCoinsValues = {};
                    var _currCurrency = $(this).data('currency-name');
                    current_coins.forEach(function (coin) {
                        _currentCoinsValues[coin] = 0;
                    });
                    var _sumOther = 0;
                    $('.knob-' + _current_algo).each(function () {
                        var _val = parseFloat($(this).val());
                        var _currency = $(this).data('currency-name');
                        _currentCoinsValues[_currency] = _val;
                        if (_currency != _currCurrency)
                            _sumOther += _val;
                    });

                    var _autoCurrency = 'BTC';
                    if (_currCurrency == 'BTC')
                        _autoCurrency = 'BTCD';

                    var _autoVal = _currentCoinsValues[_autoCurrency];
                    var _oldCurrVal = 100 - _sumOther;
                    var _oldCurrValAbs = Math.abs(wantedVal - _oldCurrVal);

                    var _checkUno = parseFloat(_autoVal) + parseFloat(wantedVal);
                    var _checkDuo = 100 - _checkUno;
                    var _checkDuoAbs = Math.abs(100 - _checkUno);

                    if (wantedVal > _oldCurrVal) {
                        var checkAutoVal = _autoVal - _oldCurrValAbs;
                        if (checkAutoVal < 0) {
                            wantedVal = _oldCurrVal + _autoVal;
                            _autoVal = 0;
                        } else
                            _autoVal = checkAutoVal;
                    }
                    // decreasing the current slider, increase the auto
                    if (wantedVal < _oldCurrVal)
                        _autoVal += _oldCurrValAbs;


                    _currentCoinsValues[_currCurrency] = wantedVal;
                    _currentCoinsValues[_autoCurrency] = _autoVal;


                    $('.knob-' + _current_algo).each(function () {
                        //shutdown callback temporary
                        $(this).trigger('configure', {
                            'release': function () {
                                return;
                            }
                        });

                        if(_current_algo == 'x11')
                            var _unnit = 'MH/s';

                        if(_current_algo == 'dagger-hashimoto')
                            var _unnit = 'MH/s';

                        if(_current_algo == 'sha256')
                            var _unnit = 'TH/s';

                        var _coin = $(this).data('currency-name');
                        var _val = _currentCoinsValues[_coin];
                        var finalPerc = parseFloat(totalMH * _val / 100).formatNumber(2, '.', '');
                        $('#' + _coin + '_value_' + _current_algo).text(finalPerc + ' ' + _unnit);
                        if (_coin != _currCurrency)
                            $(this).val(_val).trigger('change');

                        //bring callback up again
                        $(this).trigger('configure', {
                            'release': function () {
                                this.$.trigger('allocation', [this.cv, this.$]);
                            }
                        });
                    });
                });

                $('.reset-allocation').click(function (e) {
                    var _current_algo = $('#save-form-info').attr('data-form-algo');
                    e.preventDefault();
                    $('.knob-' + _current_algo).each(function () {
                        $(this).trigger('configure', {
                            'release': function () {
                                return;
                            }
                        });
                        var curr_currency = $(this).attr('data-currency-name');
                        var set_val = 0;
                        if (curr_currency == 'BTC')
                            set_val = 100;

                        if(_current_algo == 'x11')
                            var _unnit = 'MH/s';

                        if(_current_algo == 'dagger-hashimoto')
                            var _unnit = 'MH/s';

                        if(_current_algo == 'sha256')
                            var _unnit = 'TH/s';

                        var finalPerc = parseFloat(totalMH * set_val / 100).formatNumber(2, '.', '');
                        $('#' + $(this).data('currency-name') + '_value_' + _current_algo).text(finalPerc + ' ' + _unnit);

                        $(this).val(set_val).trigger('change');
                        $(this).trigger('configure', {
                            'release': function () {
                                this.$.trigger('allocation', [this.cv, this.$]);
                            }
                        });
                    });
                });

                $('.save-' + _current_algo).click(function (e) {
                    e.preventDefault();
                    $('#UserMiningDistributionForm_' + _current_algo).submit();
                });
            }

            $(".btn-close").click(function(e){
                e.preventDefault();
                $(this).parent().hide("fast");
            });
            $(".btn-more").click(function(e){
                e.preventDefault();
                $(this).next().show("fast");
            });

        })
    </script>
</div>
<div style="display:none;"><input type="hidden" name="data[_Token][fields]" value="c5e3364fad1c74480dc5c90811ee293c6d8629f1%3AUser.id" id="TokenFields1522040004"/><input type="hidden" name="data[_Token][unlocked]" value="" id="TokenUnlocked526245507"/></div></form>
