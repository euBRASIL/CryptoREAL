
var StandardInteractionsMixin = {
	dateClickingClass: DateClicking,
	dateSelectingClass: DateSelecting,
	eventPointingClass: EventPointing,
	eventDraggingClass: EventDragging,
	eventResizingClass: EventResizing,
	externalDroppingClass: ExternalDropping
};
