
$.fullCalendar.locale("es", {
	buttonText: {
		month: "Mes",
		week: "Semana",
		day: "Día",
		list: "Agenda"
	},
	allDayHtml: "Todo<br/>el día",
	eventLimitText: "más",
	noEventsMessage: "No hay eventos para mostrar"
});
