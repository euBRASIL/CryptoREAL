$.fullCalendar.locale("af", {
	buttonText: {
		year: "Jaar",
		month: "Maand",
		week: "Week",
		day: "Dag",
		list: "Agenda"
	},
	allDayHtml: "Heeldag",
	eventLimitText: "Addisionele",
	noEventsMessage: "Daar is geen gebeurtenis"
});
