
$.fullCalendar.locale("id", {
	buttonText: {
		month: "Bulan",
		week: "Minggu",
		day: "Hari",
		list: "Agenda"
	},
	allDayHtml: "Sehari<br/>penuh",
	eventLimitText: "lebih",
	noEventsMessage: "Tidak ada acara untuk ditampilkan"
});
