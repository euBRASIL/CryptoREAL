
$.fullCalendar.locale("th", {
	buttonText: {
		month: "เดือน",
		week: "สัปดาห์",
		day: "วัน",
		list: "แผนงาน"
	},
	allDayText: "ตลอดวัน",
	eventLimitText: "เพิ่มเติม",
	noEventsMessage: "ไม่มีกิจกรรมที่จะแสดง"
});
