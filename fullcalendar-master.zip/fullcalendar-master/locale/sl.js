
$.fullCalendar.locale("sl", {
	buttonText: {
		month: "Mesec",
		week: "Teden",
		day: "Dan",
		list: "Dnevni red"
	},
	allDayText: "Ves dan",
	eventLimitText: "več",
	noEventsMessage: "Ni dogodkov za prikaz"
});
