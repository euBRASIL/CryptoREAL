
$.fullCalendar.locale("eu", {
	buttonText: {
		month: "Hilabetea",
		week: "Astea",
		day: "Eguna",
		list: "Agenda"
	},
	allDayHtml: "Egun<br/>osoa",
	eventLimitText: "gehiago",
	noEventsMessage: "Ez dago ekitaldirik erakusteko"
});
