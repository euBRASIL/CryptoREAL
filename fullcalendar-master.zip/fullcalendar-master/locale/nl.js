
$.fullCalendar.locale("nl", {
	buttonText: {
		month: "Maand",
		week: "Week",
		day: "Dag",
		list: "Agenda"
	},
	allDayText: "Hele dag",
	eventLimitText: "extra",
	noEventsMessage: "Geen evenementen om te laten zien"
});
